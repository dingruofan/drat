## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 5, 
  fig.height = 4
)

## ---- echo=F------------------------------------------------------------------
options(warn=-1)

## ---- eval=F------------------------------------------------------------------
#  install.packages("devtools", repos='http://cran.us.r-project.org')
#  library(devtools)
#  install_github("cnfoley/hyprcoloc")

## -----------------------------------------------------------------------------
library(hyprcoloc)
betas <- hyprcoloc::test.betas
head(betas)
ses <- hyprcoloc::test.ses
head(ses)

## -----------------------------------------------------------------------------
trait.cor <- hyprcoloc::test.corr
ld.matrix <- hyprcoloc::test.ld

## -----------------------------------------------------------------------------
traits <- paste0("T", 1:dim(betas)[2]);
rsid <- rownames(betas);
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid);
res;

## -----------------------------------------------------------------------------
binary.traits = c(1,1,1,rep(0,dim(betas)[2]-3));
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, binary.outcomes = binary.traits);
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, trait.subset = c("T1","T2"));
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, snpscores = TRUE);

## -----------------------------------------------------------------------------
res[[1]];

## -----------------------------------------------------------------------------
head(res[[2]][[1]]);

## -----------------------------------------------------------------------------
cred.sets(res, value = 0.95);

## -----------------------------------------------------------------------------
ld.matrix["rs12117612","rs7532349"];

## -----------------------------------------------------------------------------
prior.options = c(1e-4, 1e-10, 1e-20, 1e-25, 1e-100);
for(i in prior.options){
  res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, 
                   uniform.priors = TRUE, prior.1 = i, reg.steps = 2);
  print(paste0("prior.1 = ",i));
  print(res);
  }

## -----------------------------------------------------------------------------
prior.1 = 1e-4;
prior.c.options = c(0.05, 0.02, 0.01, 0.005);
for(i in prior.c.options){
  res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid,
                   uniform.priors = FALSE, prior.1 = prior.1, prior.c = i);
  print(c(paste0("prior.1 = ",prior.1), paste0("prior.c = ",i)));
  print(res);
}


## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, uniform.priors = FALSE,
                 reg.thresh = 0.95, align.thresh = 0.95);
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, uniform.priors = FALSE,
                 reg.thresh = 0.9025, align.thresh = 0.9025);
res

## -----------------------------------------------------------------------------
sensitivity.plot(betas, ses, trait.names = traits, snp.id=rsid, 
                 reg.thresh = c(0.6,0.7,0.8,0.9), align.thresh = c(0.6,0.7,0.8,0.9), prior.c = c(0.02, 0.01, 0.005), equal.thresholds = FALSE);
# Or by fixing the regional and aligment thresholds to be equal
# sensitivity.plot(betas, ses, trait.names = traits, snp.id=rsid, 
#                  reg.thresh = c(0.6,0.7,0.8,0.9), prior.c = c(0.02, 0.01, 0.005), equal.thresholds = TRUE);

## -----------------------------------------------------------------------------
res = sensitivity.plot(betas, ses, trait.names = traits, snp.id=rsid, 
                 reg.thresh = c(0.6,0.7,0.8,0.9), align.thresh = c(0.6,0.7,0.8,0.9), prior.c = c(0.02, 0.01, 0.005), equal.thresholds = FALSE, similarity.matrix = TRUE);
# heatmap is found by typing 
heatmap.plot = res[[1]]; # (plotted previously)
# similarity matrix is found by typing
sim.mat = res[[2]];
sim.mat;

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, bb.selection = "regional");
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, bb.selection = "align");
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, bb.alg = FALSE);
res

## -----------------------------------------------------------------------------
ptm = proc.time();
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, bb.selection = "reg.only", reg.thresh = 0.9);
proc.time() - ptm;
res

## -----------------------------------------------------------------------------
# 100 traits
# beta100 replicates the betas for clusters 1, 2 and 3 10 times  
traits100 <- paste0("T", 1:100)
betas100 = ses100 = NULL;
clusters = c(1,2,3);
clst.traits = list(1:5, 6:8, 9:10);
times = 10;
  for(c in clusters){
    tmp.betas = tmp.ses = NULL;
    traits = clst.traits[[c]];
        for(i in 1:times){
            tmp.betas = cbind(tmp.betas, betas[,traits]); 
            tmp.ses = cbind(tmp.ses, ses[,traits]);
          }
    betas100 = cbind(betas100, tmp.betas);
    ses100 = cbind(ses100, tmp.ses)
  }
ptm = proc.time(); 
res = hyprcoloc(betas100, ses100, trait.names = traits100, snp.id = rsid);
proc.time()-ptm;

# print the number of traits in each cluster
clusters = which(! is.na(res$results$traits));
for(c in clusters){
traits = unlist(strsplit(res$results$traits[c], split=", "));
head.traits = head(traits);
tail.traits = tail(traits);
# print the head and tail of the traits in each cluster
print(paste0("cluster ",c," contains ",length(traits), " traits"));
print("#####");
print(c(head.traits, "...", tail.traits));
print("#####");
}

## -----------------------------------------------------------------------------
# 1000 traits
traits1000 <- paste0("T", 1:1000)
betas1000 = ses1000 = NULL;
clusters = c(1,2,3);
clst.traits = list(1:5, 6:8, 9:10);
times = 100;
  for(c in clusters){
    tmp.betas = tmp.ses = NULL;
    traits = clst.traits[[c]];
        for(i in 1:times){
            tmp.betas = cbind(tmp.betas, betas[,traits]); 
            tmp.ses = cbind(tmp.ses, ses[,traits]);
          }
    betas1000 = cbind(betas1000, tmp.betas);
    ses1000 = cbind(ses1000, tmp.ses)
  }
ptm = proc.time(); 
res = hyprcoloc(betas1000, ses1000, trait.names = traits1000, snp.id = rsid);
proc.time()-ptm;

# print the number of traits in each cluster
# print the number of traits in each cluster
clusters = which(! is.na(res$results$traits));
for(c in clusters){
traits = unlist(strsplit(res$results$traits[c], split=", "));
head.traits = head(traits);
tail.traits = tail(traits);
# print the head and tail of the traits in each cluster
print(paste0("cluster ",c," contains ",length(traits), " traits"));
print("#####");
print(c(head.traits, "...", tail.traits));
print("#####");
}

## -----------------------------------------------------------------------------
# default assumption, presented for clarity:
sample.overlap = matrix(1, dim(betas)[2], dim(betas)[2]); 

## -----------------------------------------------------------------------------
traits <- paste0("T", 1:dim(betas)[2]);
ptm = proc.time();
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, trait.cor = trait.cor, 
                 ld.matrix = ld.matrix, sample.overlap = sample.overlap, uniform.priors = FALSE);
time.corr = proc.time() - ptm;
res

## -----------------------------------------------------------------------------
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid, trait.cor = trait.cor,
                 ld.matrix = ld.matrix, sample.overlap = sample.overlap, uniform.priors = TRUE);
res

## -----------------------------------------------------------------------------
ptm = proc.time();
res <- hyprcoloc(betas, ses, trait.names=traits, snp.id=rsid);
time.ind = proc.time() - ptm;
time.ind;
time.corr;

